package backend.belatro.enums;

public enum FriendshipStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    CANCELLED
}
