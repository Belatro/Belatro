package backend.belatro.enums;

public enum queueStatus {
    QUEUED,
    MATCHED,
    CANCELLED
}
