package backend.belatro.enums;

public enum lobbyStatus {
    WAITING,
    CLOSED
}
