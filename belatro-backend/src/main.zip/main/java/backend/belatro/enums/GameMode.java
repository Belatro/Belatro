package backend.belatro.enums;

public enum GameMode {
    CASUAL,
    RANKED
}
