package backend.belatro.pojo.gamelogic.enums;

public enum Rank {
    SEDMICA,
    OSMICA,
    DEVETKA,
    DECKO,
    BABA,
    KRALJ,
    DESETKA,
    AS
}
