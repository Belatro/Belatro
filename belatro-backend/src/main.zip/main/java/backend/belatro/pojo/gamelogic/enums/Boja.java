package backend.belatro.pojo.gamelogic.enums;

public enum Boja {
    KARA,
    HERC,
    TREF,
    PIK
}
